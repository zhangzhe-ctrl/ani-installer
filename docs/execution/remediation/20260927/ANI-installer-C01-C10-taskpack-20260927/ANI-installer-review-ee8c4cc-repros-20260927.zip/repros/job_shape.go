// Production string-emitter fragment, ee8c4ccf verify.go/runCheckJob.
// No Kubernetes/Helm invocation; example namespace/name/image only.
package main
import("fmt";"strings")
func main(){
 namespace,name,image:="review-only","isolated-check","offline.example/client:pinned"
 var b strings.Builder
 b.WriteString("apiVersion: batch/v1\nkind: Job\nmetadata:\n")
 fmt.Fprintf(&b,"  name: %s\n  namespace: %s\n",name,namespace)
 b.WriteString("  labels:\n    app.kubernetes.io/name: ani-acceptance\nspec:\n  backoffLimit: 0\ntemplate:\n")
 b.WriteString("  metadata:\n    labels:\n      app.kubernetes.io/name: ani-acceptance\n")
 b.WriteString("  spec:\n    restartPolicy: Never\n    containers:\n")
 fmt.Fprintf(&b,"      - name: client\n        image: %s\n        imagePullPolicy: IfNotPresent\n",image)
 b.WriteString("        command:\n          - /bin/sh\n          - -c\n")
 fmt.Fprintf(&b,"          - |\n%s\n","            true")
 fmt.Print(b.String())
}
