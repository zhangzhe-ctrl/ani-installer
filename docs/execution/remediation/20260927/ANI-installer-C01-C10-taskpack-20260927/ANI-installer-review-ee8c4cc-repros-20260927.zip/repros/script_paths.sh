#!/usr/bin/env bash
# Original header/helper snippets; fake external command, no cluster access.
set -euo pipefail
D="$(mktemp -d)"
trap 'rm -rf "$D"' EXIT
export TRACE="$D/trace"
mkdir "$D/bin"
cat > "$D/bin/kubectl" <<'FAKE'
#!/usr/bin/env bash
printf 'ambient=%s args=%s\n' "${KUBECONFIG:-unset}" "$*" >> "$TRACE"
FAKE
chmod +x "$D/bin/kubectl"
export PATH="$D/bin:$PATH"
export KUBECONFIG=/isolated/explicit-A.conf
unset ANI_VERIFY_KUBECONFIG
# Actual NATS checker kubeconfig header (invoked from role with only KUBECONFIG set).
KUBECONFIG_FILE="${ANI_VERIFY_KUBECONFIG:-/etc/kubernetes/admin.conf}"
KUBECTL=(kubectl --kubeconfig "$KUBECONFIG_FILE")
"${KUBECTL[@]}" get statefulset nats
# Actual Fluent Bit helper and variables, invoked with an explicit verifier override.
export ANI_VERIFY_KUBECONFIG=/isolated/expected-B.conf
NS=ani-observability
KC="kubectl -n $NS"
CLIENT_POD="ani-fluent-bit-verify-client"
TOOL_IMAGE=offline.example/python:pinned
start_client() {
  $KC delete pod "$CLIENT_POD" --ignore-not-found --wait=true --timeout=300s >/dev/null
  $KC run "$CLIENT_POD" --image="$TOOL_IMAGE" --restart=Never \
    --command -- python3 -c 'import time; time.sleep(3600)' >/dev/null
  $KC wait --for=condition=Ready "pod/$CLIENT_POD" --timeout=180s
}
start_client
start_client
cat "$TRACE"
