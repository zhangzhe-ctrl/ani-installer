// Isolated reproduction of ee8c4ccf verify.go's subprocess setup.
// Does not import/run installer or contact Kubernetes. Parent/children are created here only.
package main
import("context";"fmt";"os";"os/exec";"path/filepath";"syscall";"time")
func scenario(fix bool) error {
 d,err:=os.MkdirTemp("","ani-cancel-review-"); if err!=nil{return err}; defer os.RemoveAll(d)
 marker:=filepath.Join(d,"child-after-cancel")
 script:=filepath.Join(d,"script.sh")
 err=os.WriteFile(script,[]byte("#!/bin/bash\n(sleep 1; printf survived > \"$1\") &\nwait\n"),0600); if err!=nil{return err}
 ctx,cancel:=context.WithTimeout(context.Background(),150*time.Millisecond); defer cancel()
 cmd:=exec.CommandContext(ctx,"bash",script,marker)
 nonNil:=cmd.Cancel!=nil
 cmd.SysProcAttr=&syscall.SysProcAttr{Setpgid:true}
 called:=false
 killGroup:=func()error{called=true; if cmd.Process==nil{return nil}; return syscall.Kill(-cmd.Process.Pid,syscall.SIGKILL)}
 // Current production guard vs narrowly corrected positive control.
 if fix { cmd.Cancel=killGroup } else if cmd.Cancel==nil { cmd.Cancel=killGroup }
 if cmd.WaitDelay==0 {cmd.WaitDelay=5*time.Second}
 start:=time.Now(); _,runerr:=cmd.CombinedOutput()
 time.Sleep(1100*time.Millisecond)
 _,staterr:=os.Stat(marker)
 fmt.Printf("fix=%v default_cancel_non_nil=%v group_callback_called=%v child_wrote_after_cancel=%v duration_ms=%d command_error=%v\n",fix,nonNil,called,staterr==nil,time.Since(start).Milliseconds(),runerr)
 // Best-effort cleanup only of the group created by THIS isolated scenario.
 if cmd.Process!=nil {_=syscall.Kill(-cmd.Process.Pid,syscall.SIGKILL)}
 if !fix && (called || staterr!=nil) {return fmt.Errorf("expected current-code behaviour not observed")}
 if fix && (!called || staterr==nil) {return fmt.Errorf("control did not stop descendants")}
 return nil
}
func main(){for _,fix:=range []bool{false,true}{if err:=scenario(fix);err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(1)}}}
