// Isolated copy of ee8c4ccf componentsScope plus execute's set comparison.
// Minimal data stubs only, no external APIs/installer command execution.
package main
import("errors";"fmt";"sort";"strings")
type row struct{Name string;Enabled bool}
type comps []row
func(c comps)Selection()[]row{return c}
type ClusterConfig struct{Components comps}
type spec struct{InternalDeps []string;NeedsStorage bool}
var componentInstallSpecs=map[string]spec{"opensearch":{InternalDeps:[]string{"fluent-bit"},NeedsStorage:true},"fluent-bit":{}}
var componentsDeferred=[]string{}
func effectiveStorageClass(ClusterConfig)string{return "existing-class"}
func componentsScope(cluster ClusterConfig, only []string) ([]string, error) {
 trimmed := make([]string, 0, len(only))
 for _, name := range only { if name = strings.TrimSpace(name); name != "" {trimmed = append(trimmed, name)} }
 only = trimmed
 if len(only) == 0 {return nil, errors.New("--only is required and must name at least one component; a components run never implies a scope")}
 enabled := map[string]bool{}
 for _, row := range cluster.Components.Selection() {enabled[row.Name] = row.Enabled}
 var scope []string
 seen := map[string]bool{}
 var add func(name string) error
 add = func(name string) error {
  if seen[name] {return nil}
  spec, known := componentInstallSpecs[name]
  if !known {
   for _, deferred := range componentsDeferred {if name == deferred {return fmt.Errorf("component %q is a deferred batch; this installer does not implement it yet",name)}}
   return fmt.Errorf("unknown component id %q",name)
  }
  if !enabled[name] {return fmt.Errorf("component %q is not enabled in the site config; enable it there first — a components run never edits the config silently",name)}
  seen[name]=true
  for _,dep:=range spec.InternalDeps {
   if !enabled[dep] {return fmt.Errorf("component %q requires %q, which the site config has not enabled",name,dep)}
   if err:=add(dep);err!=nil{return err}
  }
  scope=append(scope,name)
  return nil
 }
 for _,name:=range only {if err:=add(strings.TrimSpace(name));err!=nil{return nil,err}}
 class:=effectiveStorageClass(cluster)
 for _,name:=range scope {if componentInstallSpecs[name].NeedsStorage && class=="" {return nil,fmt.Errorf("component %q needs storage",name)}}
 return scope,nil
}
func main(){
 c:=ClusterConfig{Components:comps{{"fluent-bit",true},{"opensearch",true}}}
 for _,p:=range [][]string{{"fluent-bit","opensearch"},{"opensearch"}}{
  re,err:=componentsScope(c,p);if err!=nil{panic(err)}
  plannedSorted:=append([]string(nil),p...);sort.Strings(plannedSorted)
  recomputedSorted:=append([]string(nil),re...);sort.Strings(recomputedSorted)
  reject:=strings.Join(recomputedSorted,",")!=strings.Join(plannedSorted,",")
  fmt.Printf("planned=%v full_dependency_closure=%v execute_rejects=%v\n",p,re,reject)
 }
}
