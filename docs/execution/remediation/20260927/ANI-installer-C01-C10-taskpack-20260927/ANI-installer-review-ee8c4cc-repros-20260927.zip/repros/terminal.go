// Isolated control-flow reproduction of runner.go at ee8c4cc.
// External installation and file writes are simulated; this is NOT RunInstall.
package main

import (
    "errors"
    "fmt"
)

func run(recordWriteFails bool) (retErr error) {
    stateResult := "running"
    statePhase := "cluster_built"
    installSucceeded := false
    defer func() {
        // The guard and transitions reproduce the production finalizer.
        if stateResult != "succeeded" {
            switch {
            case retErr == nil && installSucceeded:
                stateResult = "succeeded"
            case retErr != nil:
                stateResult = "failed"
            }
            if stateResult == "running" { stateResult = "failed" }
        }
        fmt.Printf("record_write_fails=%v return_error=%v persisted_result=%s persisted_phase=%s\n", recordWriteFails, retErr != nil, stateResult, statePhase)
    }()
    // Production sets these before Build/WriteInstallSuccessRecord.
    statePhase = "succeeded"
    stateResult = "succeeded"
    if recordWriteFails { return errors.New("simulated WriteInstallSuccessRecord failure") }
    installSucceeded = true
    return nil
}
func main() { _ = run(false); _ = run(true) }
