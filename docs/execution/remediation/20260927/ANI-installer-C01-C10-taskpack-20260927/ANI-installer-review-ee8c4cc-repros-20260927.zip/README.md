# 复现包

对应固定提交 ee8c4ccf4f6168d94c6abbafd13896f2d3af2061。
本次未构建完整仓库；源码是从GitHub连接器读取，克隆受DNS限制。
复现为摘取生产片段＋必要适配，不能冒充完整产品测试或实机结果。
执行环境：Linux、Go1.23.2、Bash、Python3/PyYAML。未降低仓库go.mod。
不运行installer、不连接Kubernetes/SSH/ESXi、不读取用户凭据。

复跑（在该包目录；只会创建自己的临时文件和取消测试进程）：

```bash
GOTOOLCHAIN=local go run repros/cancel.go
GOTOOLCHAIN=local go run repros/job_shape.go
GOTOOLCHAIN=local go run repros/scope.go
bash repros/script_paths.sh
GOTOOLCHAIN=local go run repros/terminal.go
```

job-shape.out是将实际发射的YAML用PyYAML解析并与spec.template缩进对照的结果。
现有.out是本次实际执行输出；复跑的耗时、临时路径自然会不同。
Bug observed意味着观察到问题，不意味着产品验收通过。
使用固定源码来源与完整报告核对上下文；适配为正式回归时要调用真实生产函数，勿将摘取片段当成正式测试替身。
