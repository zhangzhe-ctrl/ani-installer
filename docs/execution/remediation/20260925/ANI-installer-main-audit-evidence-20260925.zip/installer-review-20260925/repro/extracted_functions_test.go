package auditrepro
import (
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "strings"
 "testing"
)
// PASS means observed current defect/behavior, NOT that product acceptance passes.
func TestObservedUnitCheckDefects(t *testing.T) {
 t.Run("nil runner always succeeds",func(t *testing.T){
  if err:=CheckUnitInactive("unit-that-is-never-executed",nil);err!=nil {t.Fatal(err)}
  t.Log("BUG_OBSERVED: production nil-runner path executes no systemctl and returns nil")
 })
 t.Run("active accepted",func(t *testing.T){
  calls:=0
  err:=CheckUnitInactive("example.service",func(string,...string)error{calls++;return nil})
  if err!=nil||calls!=1{t.Fatalf("unexpected %v %d",err,calls)}
  t.Log("BUG_OBSERVED: an is-active command returning zero is accepted")
 })
 t.Run("inactive rejected as active",func(t *testing.T){
  err:=CheckUnitInactive("example.service",func(string,...string)error{return fmt.Errorf("exit status 3")})
  if err==nil||!strings.Contains(err.Error(),"is active"){t.Fatalf("unexpected %v",err)}
  t.Logf("BUG_OBSERVED: %v",err)
 })
}
func writeJSON(t *testing.T,path string,x any) {
 t.Helper(); b,e:=json.Marshal(x);if e!=nil{t.Fatal(e)};if e=os.WriteFile(path,b,0600);e!=nil{t.Fatal(e)}
}
func TestObservedVerifyStateDefects(t *testing.T) {
 for _,phase:=range []string{"installing","preflight_failed","registry_content_verified"} {
  t.Run(phase,func(t *testing.T){
   d:=t.TempDir();p:=filepath.Join(d,"run.json")
   writeJSON(t,p,RunManifest{ConfigDigest:strings.Repeat("a",64),ClusterName:"lab"})
   writeJSON(t,filepath.Join(d,"run-state.json"),InstallState{RunID:"install-attempt",Phase:phase,ClusterName:"lab",ConfigDigest:strings.Repeat("b",64),RemoteResult:"remote_result_unknown"})
   _,id,e:=loadVerifyRun(VerifyInput{RunFile:p})
   if e!=nil||id!="install-attempt"{t.Fatalf("unexpected id=%q err=%v",id,e)}
   t.Logf("BUG_OBSERVED: phase=%s + mismatched configDigest + remote_result_unknown accepted",phase)
  })
 }
 t.Run("no install state required",func(t *testing.T){
  d:=t.TempDir();p:=filepath.Join(d,"run.json")
  writeJSON(t,p,RunManifest{ConfigDigest:strings.Repeat("a",64),ClusterName:"lab"})
  _,id,e:=loadVerifyRun(VerifyInput{RunFile:p});if e!=nil{t.Fatal(e)}
  t.Logf("OBSERVED: validation-only record accepted id=%s",id)
 })
 t.Run("short digest panic",func(t *testing.T){
  d:=t.TempDir();p:=filepath.Join(d,"run.json")
  writeJSON(t,p,RunManifest{ConfigDigest:"x",ClusterName:"lab"})
  var got any
  func(){defer func(){got=recover()}();_,_,_=loadVerifyRun(VerifyInput{RunFile:p})}()
  if got==nil{t.Fatal("expected current short-digest panic was not observed")}
  t.Logf("BUG_OBSERVED: %v",got)
 })
 t.Run("explicit failed state rejected control",func(t *testing.T){
  d:=t.TempDir();p:=filepath.Join(d,"run.json")
  writeJSON(t,p,RunManifest{ConfigDigest:strings.Repeat("a",64),ClusterName:"lab"})
  writeJSON(t,filepath.Join(d,"run-state.json"),InstallState{RunID:"failed",Phase:"install_failed",ClusterName:"lab"})
  _,_,e:=loadVerifyRun(VerifyInput{RunFile:p});if e==nil{t.Fatal("control: expected rejection")}
  t.Log("CONTROL: exact install_failed is rejected")
 })
}
