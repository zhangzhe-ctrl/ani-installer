#!/usr/bin/env bash
# Isolated exact helper-body reproduction of metrics/templates/verify.sh.
# Calls named fake_kubectl and k5_pod_ready below are fixture functions only.
set -euo pipefail
: "${OUT_DIR:?fixture directory required}"
NS=fixture-namespace
KUBECTL=(fake_kubectl)
fake_kubectl() { printf '%s\n' "$*" >> "$OUT_DIR/kubectl-calls.log"; }
ready_calls=0
k5_pod_ready() { ready_calls=$((ready_calls+1)); [ "$ready_calls" -ge 2 ]; }
k5_collect_failure_evidence() { :; }
# Original function body from pinned main, source approx lines 105-124.
k5_rebuild_wait() {
  local sel="$1" what="$2" t1="$3" t2="$4"
  if k5_pod_ready "$sel" "$t1"; then
    return 0
  fi
  echo "  K5_REBUILD $what: not Ready within $t1; performing the one planned rebuild of this component's pod"
  echo "k5_rebuild_planned $what $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$OUT_DIR/k5-retries.txt"
  "${KUBECTL[@]}" -n "$NS" delete pod -l "$sel" --timeout=180s >/dev/null 2>&1 || true
  if k5_pod_ready "$sel" "$t2"; then
    return 0
  fi
  echo "  K5_REBUILD $what: still not Ready within $t2; no further rebuild and no agent restart is attempted" >&2
  k5_collect_failure_evidence "$sel" "$what" || true
  return 1
}
# Original call sequence in [7/8] of the metrics script, with fail stub.
fail() { echo "FAIL: $*" >&2; exit 1; }
"${KUBECTL[@]}" -n "$NS" delete pod -l app.kubernetes.io/name=prometheus --timeout=180s >/dev/null
k5_rebuild_wait "app.kubernetes.io/name=prometheus" "prometheus" 600s 420s \
  || fail "Prometheus did not come back after the rebuild (no further rebuild or agent restart is attempted)"
printf 'mock_delete_calls=%s\n' "$(grep -c 'delete pod' "$OUT_DIR/kubectl-calls.log")"
