// Isolated review harness. Function bodies below are copied from pinned main
// f58430e84a1949b837c59139dc45979c33ae5c4f; support types/error adapter are minimal
// test scaffolding, not replacement product implementations. No real cluster use.
package auditrepro

import (
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
)

// Support scaffolding: only fields used by the original loadVerifyRun function.
type VerifyInput struct { RunFile, StateFile string }
type RunManifest struct {
 ConfigDigest string `json:"configDigest"`
 ClusterName string `json:"clusterName"`
}
type InstallState struct {
 RunID string `json:"runId"`
 Phase string `json:"phase"`
 ClusterName string `json:"clusterName"`
 ConfigDigest string `json:"configDigest"`
 RemoteResult string `json:"remoteResult"`
}
var errors = struct { Wrapf func(error, string, ...any) error }{
 Wrapf: func(err error, f string, args ...any) error { return fmt.Errorf("%s: %w", fmt.Sprintf(f,args...),err) },
}
func ReadRunState(path string) (*InstallState, error) {
 data, err := os.ReadFile(path)
 if err != nil { return nil, err }
 var state InstallState
 if err := json.Unmarshal(data, &state); err != nil { return nil, errors.Wrapf(err, "parse %s", path) }
 return &state, nil
}

// Original function body: kubekey/pkg/ani/preflight.go / CheckUnitInactive.
func CheckUnitInactive(unit string, runner func(string, ...string) error) error {
	if runner == nil {
		runner = func(name string, args ...string) error { return nil }
	}
	if err := runner("systemctl", "is-active", "--quiet", unit); err != nil {
		return fmt.Errorf("unit %s is active; stop and disable it deliberately before installing", unit)
	}
	return nil
}

// Original function body: kubekey/pkg/ani/verify.go / loadVerifyRun.
func loadVerifyRun(input VerifyInput) (RunManifest, string, error) {
	data, err := os.ReadFile(input.RunFile)
	if err != nil {
		return RunManifest{}, "", errors.Wrapf(err, "read the run record %s", input.RunFile)
	}
	var manifest RunManifest
	if err := json.Unmarshal(data, &manifest); err != nil {
		return RunManifest{}, "", errors.Wrapf(err, "parse the run record %s", input.RunFile)
	}
	if manifest.ConfigDigest == "" || manifest.ClusterName == "" {
		return RunManifest{}, "", fmt.Errorf("%s is not a run.json record (missing configDigest/clusterName)", input.RunFile)
	}

	runID := ""
	statePath := input.StateFile
	if statePath == "" {
		candidate := filepath.Join(filepath.Dir(input.RunFile), "run-state.json")
		if _, err := os.Stat(candidate); err == nil {
			statePath = candidate
		}
	}
	if statePath != "" {
		state, err := ReadRunState(statePath)
		if err != nil {
			return RunManifest{}, "", errors.Wrapf(err, "read the install state %s", statePath)
		}
		if state.ClusterName != manifest.ClusterName {
			return RunManifest{}, "", fmt.Errorf("install state belongs to cluster %q, run record to %q", state.ClusterName, manifest.ClusterName)
		}
		if state.Phase == "install_failed" {
			return RunManifest{}, "", fmt.Errorf("the install run %s failed (phase=%s); verification requires a successful install", state.RunID, state.Phase)
		}
		runID = state.RunID
	}
	if runID == "" {
		// A validation-only record: deterministic identity from its digest, so
		// reports are still tied to exactly one run record.
		runID = "record-" + manifest.ConfigDigest[:12]
	}
	return manifest, runID, nil
}
