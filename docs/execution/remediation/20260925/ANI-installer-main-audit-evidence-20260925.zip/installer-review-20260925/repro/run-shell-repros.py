#!/usr/bin/env python3
"""Non-destructive excerpt tests. PASS/bug_observed means a bug was reproduced.
No SSH, kubectl, container runtime or installer is invoked.
"""
from pathlib import Path
import gzip, hashlib, io, json, os, subprocess, tarfile, tempfile
HERE=Path(__file__).resolve().parent
RESULTS=HERE.parent/'results'
RESULTS.mkdir(exist_ok=True)
def make_chart(name:str)->bytes:
    b=io.BytesIO()
    with tarfile.open(fileobj=b,mode='w') as t:
        data=f'apiVersion: v2\nname: {name}\nversion: 1.0.0\n'.encode()
        member=tarfile.TarInfo(f'{name}/Chart.yaml');member.size=len(data);member.mtime=0
        t.addfile(member,io.BytesIO(data))
    return gzip.compress(b.getvalue(),mtime=0)
def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()
results=[]
with tempfile.TemporaryDirectory(prefix='ani-audit-k5-') as td:
    p=subprocess.run(['bash',str(HERE/'k5-excerpt.sh')],env={**os.environ,'OUT_DIR':td},capture_output=True,text=True,timeout=10)
    log=(Path(td)/'kubectl-calls.log').read_text()
    obs=p.returncode==0 and log.count('delete pod')==2
    assert obs,(p.returncode,p.stdout,p.stderr,log)
    results.append({'case':'metrics_second_failure_triggered_recreate','exit_code':p.returncode,'mock_delete_calls':2,'bug_observed':obs,'stdout':p.stdout,'command_trace':log})
for wrong in (False,True):
    with tempfile.TemporaryDirectory(prefix='ani-audit-chart-') as td:
        root=Path(td);charts=root/'charts';out=root/'output';out.mkdir()
        a,b=make_chart('alpha'),make_chart('beta')
        for n,data in [('alpha',b if wrong else a),('beta',b)]:
            d=charts/n;d.mkdir(parents=True);(d/'1.0.0.tgz').write_bytes(data)
        lock=root/'components.lock.yaml'
        lock.write_text(f'charts:\n  - name: alpha\n    artifactChartPath: charts/alpha/1.0.0.tgz\n    sha256: {sha(a)}\n  - name: beta\n    artifactChartPath: charts/beta/1.0.0.tgz\n    sha256: {sha(b)}\n')
        p=subprocess.run(['bash',str(HERE/'chart-copy-excerpt.sh')],env={**os.environ,'CHARTS_DIR':str(charts),'OUTPUT':str(out),'COMPONENT_LOCK':str(lock)},capture_output=True,text=True,timeout=15)
        actual=sha((out/'charts/alpha/1.0.0.tgz').read_bytes()) if (out/'charts/alpha/1.0.0.tgz').exists() else None
        assert p.returncode==0,(p.returncode,p.stderr)
        assert (actual!=sha(a))==wrong
        results.append({'case':'wrong_chart_hash_bound_to_alpha' if wrong else 'correct_chart_pairing_control','exit_code':p.returncode,'approved_alpha_sha256':sha(a),'packaged_alpha_sha256':actual,'bug_observed':wrong and actual!=sha(a),'stdout':p.stdout})
(RESULTS/'shell-excerpts.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
