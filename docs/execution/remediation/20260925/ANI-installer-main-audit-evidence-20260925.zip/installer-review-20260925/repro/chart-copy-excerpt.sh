#!/usr/bin/env bash
# Actual chart-selection/copy logic from pinned main build-offline.sh.
# Supplied inputs are generated non-executable toy Helm charts in a tempdir.
set -euo pipefail
: "${CHARTS_DIR:?}" "${OUTPUT:?}" "${COMPONENT_LOCK:?}"
charts_copied=0
declare -A chart_placed
while IFS= read -r chart_source; do
  chart_sha="$(sha256sum "$chart_source" | awk '{print $1}')"
  approved="$(grep -F "$chart_sha" "$COMPONENT_LOCK" | head -1 || true)"
  if [[ -z "$approved" ]]; then
    echo "chart $chart_source (sha256 $chart_sha) is not approved in $COMPONENT_LOCK; refusing to package an unknown chart" >&2
    exit 1
  fi
done < <(find "$CHARTS_DIR" -type f -name '*.tgz' | sort)
while IFS= read -r rel; do
  [[ -n "$rel" ]] || continue
  base="$(basename "$rel")"
  name="$(echo "$rel" | cut -d/ -f2)"
  chart_source=""
  while IFS= read -r candidate; do
    cand_sha="$(sha256sum "$candidate" | awk '{print $1}')"
    if grep -qF "$cand_sha" "$COMPONENT_LOCK" && grep -qF "$rel" "$COMPONENT_LOCK"; then
      : # content hash + lock path both match below; use name-based fallback
    fi
  done < <(find "$CHARTS_DIR/$name" -type f -name '*.tgz' 2>/dev/null | sort)
  for candidate in "$CHARTS_DIR/$name"/*.tgz; do
    [[ -f "$candidate" ]] || continue
    cand_sha="$(sha256sum "$candidate" | awk '{print $1}')"
    if grep -qF "$cand_sha" "$COMPONENT_LOCK"; then
      chart_source="$candidate"
      break
    fi
  done
  if [[ -z "$chart_source" ]]; then
    echo "chart set does not match the lock: lock chart $rel has no hash-approved source in $CHARTS_DIR/$name" >&2
    exit 1
  fi
  mkdir -p "$OUTPUT/$(dirname "$rel")"
  install -m 0644 "$chart_source" "$OUTPUT/$rel"
  chart_placed["$rel"]=1
  charts_copied=$((charts_copied + 1))
done < <(grep -oE 'artifactChartPath: \S+' "$COMPONENT_LOCK" | awk '{print $2}')
lock_chart_count="$(grep -c 'artifactChartPath:' "$COMPONENT_LOCK")"
if [[ "$charts_copied" != "$lock_chart_count" ]]; then
  echo "chart set does not match the lock: $charts_copied placed, $lock_chart_count approved entries" >&2
  exit 1
fi
echo "packaged $charts_copied chart archives at lock artifactChartPath layout, all hash-approved in the lock"
