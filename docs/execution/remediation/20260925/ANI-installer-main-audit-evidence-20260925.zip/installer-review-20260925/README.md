# ANI installer 固定 main 复审证据包

固定提交：`f58430e84a1949b837c59139dc45979c33ae5c4f`。

## 内容与可信度

- `audit.md`：完整静态复审、修复建议、固定提交源码索引。
- `repro/extracted_functions.go` / `_test.go`：两个原函数体配最小类型与错误包装适配，在独立标准库 Go 环境运行。**不是完整仓库 checkout/build**。
- `repro/k5-excerpt.sh`：原 metrics helper 及原调用序列配 fake kubectl/Ready 检查。没有真实命令连接集群。
- `repro/chart-copy-excerpt.sh`：原 Chart 选择/复制循环，输入仅为临时生成的两个 toy Chart。
- `repro/run-shell-repros.py`：以上 shell 场景和正确配对对照。
- `results/`：本次实际本地运行输出。PASS 表示预期行为被观察，不是原产品验收通过。
- `repro/review_regression_test.go.example`：建议放入真实仓库的回归测试，**只做 gofmt 语法处理，未完整编译执行**；预期在本提交失败。

没有保存真实密码、kubeconfig 或用户集群数据，没有原始私密仓库完整拷贝。函数/片段来自用户指定仓库（Apache-2.0 声明见上游源文件），本包保留出处，使用时应保留原许可与归属。

## 重跑已执行的隔离场景

```bash
cd repro
GO111MODULE=off GOTOOLCHAIN=local go test -v -count=1 .
python3 run-shell-repros.py
```

上面测试会创建临时目录及包内 results 输出；不会运行真实 SSH/systemctl/kubectl/installer。

## 将建议回归放入真实仓库

在单独的审核工作树进行，先确认目标文件不存在，勿覆盖已有测试：

```bash
# REPO 是经过核准的仓库根目录
# 从本证据包根运行；不自动提交
 test ! -e "$REPO/kubekey/pkg/ani/review_regression_test.go"
 cp repro/review_regression_test.go.example "$REPO/kubekey/pkg/ani/review_regression_test.go"
 cd "$REPO/kubekey"
 GOTOOLCHAIN=local go test -v -count=1 ./pkg/ani -run '^TestAudit'
```

该建议文件使用固定提交现有接口；若主分支接口已变化，先核对后适配。不要以删除失败用例的方式通过。

## 测试限制

本沙箱 Go 1.23.2；仓库 go.mod 要求 1.25.0。完整克隆因 DNS 不可用失败，故从已连接 GitHub 工具读取固定源代码，不使用旧上传 ZIP 代替最新 main。GitHub CI 的绿色结果经 API/日志核对，但属于 GitHub 运行，不是本沙箱执行。

SHA256SUMS 只验证本证据包传输完整性，不证明组件镜像真实性或用户实机验收通过。
